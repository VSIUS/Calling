# Call – máy chủ giao tiếp (Signaling)

Máy chủ này tương thích với giao thức Socket.IO đang có trong Call V5/V6:
- `join-room` với `{ "room": "123456" }`
- `peer-joined`
- `signal` với `offer`, `answer`, `candidate`
- `room-error`, `peer-left`

## Chạy thử trên máy tính

Yêu cầu Node.js 18 trở lên:

```bash
cd server
npm install
npm start
```

Mở `http://localhost:3000/health` để kiểm tra. Khi chạy trên Internet, ứng dụng Android phải kết nối bằng URL HTTPS/WSS do nền tảng hosting cấp.

## Triển khai trên hosting

Tạo một Web Service từ thư mục `server/`:
- Build command: `npm install`
- Start command: `npm start`
- Runtime: Node.js 18+
- Port: đọc từ biến môi trường `PORT` (hosting tự cấp)

Gói này không tự tạo hosting và không tự cấp tên miền. Dịch vụ miễn phí có thể ngủ, giới hạn giờ chạy hoặc thay đổi chính sách; cần kiểm tra điều khoản hiện tại trước khi chọn. Không có cam kết 24/7.

## Cấu hình ứng dụng Android

Trong Call V6, ô Máy chủ hiện lấy URL từ `serverInput`. Sau khi triển khai, nhập URL HTTPS của Web Service, ví dụ `https://ten-dich-vu-cua-ban.example`. Không nhập URL ví dụ này nguyên trạng.

## Giới hạn và bảo mật

- Đây là signaling server: nó chuyển SDP/ICE để hai thiết bị thương lượng WebRTC; mặc định không chuyển tiếp âm thanh.
- Call V6 hiện chỉ cấu hình STUN công khai. Một số mạng/NAT cần TURN để gọi được; signaling server này không thay thế TURN.
- Mã phòng 6 chữ số chỉ là mã ngẫu nhiên, không phải xác thực mạnh. Dùng thử với người quen; không gửi thông tin nhạy cảm.
- Server có giới hạn số người/phòng, kiểm tra payload và giới hạn tốc độ cơ bản, nhưng chưa phải dịch vụ sản xuất đã kiểm thử bảo mật.
- HTTPS/WSS phải được cung cấp bởi hosting hoặc reverse proxy. Không bật HTTP không mã hóa cho máy chủ công khai.
